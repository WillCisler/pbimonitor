# Tenant Settings Timer
Fetches the current tenant setting using the Fabric | Tenants - Get Tenant Settings API
Although it is not the Power BI Admin API your Service Pricipal / Admin account will work with this API and so will the Power BI powershell cmdlets
https://learn.microsoft.com/en-us/rest/api/fabric/admin/tenants/get-tenant-settings